﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Shooping_System
{
     internal class MainProgram
    {
        public static void MainMenu( /*Foods food, Drinks drink, ShowerTools shower*/)
        {

        }
    }
}
