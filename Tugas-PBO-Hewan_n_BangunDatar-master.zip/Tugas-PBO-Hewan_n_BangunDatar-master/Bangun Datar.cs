﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Tugas_PBO_Hewan_n_BangunDatar
{
   internal class Bangun_Datar
    {
        public const double PI = Math.PI;
        public double r;
        public double L; 


        public double Area(double Radius)
        {
            return L = PI * Math.Pow(Radius, Radius);
        }

    }
}
