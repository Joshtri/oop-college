﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _3._28._22___OOP_using_base__2
{
    class Program
    {
        static void Main(string[] args)
        {
            SegiEmpatBerwarna obj = new SegiEmpatBerwarna(8,4, "Pink");
            obj.CetakData(); 


        }
    }
}
