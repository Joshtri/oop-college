﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Belajar_OOP_Eps_2
{
    internal class SegiEmpat : BangunDatar
    { 
    
    }
}
