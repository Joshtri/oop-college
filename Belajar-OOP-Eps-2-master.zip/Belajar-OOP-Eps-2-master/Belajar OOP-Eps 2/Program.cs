﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Belajar_OOP_Eps_2
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Segitiga obj = new Segitiga(5,10, 2,10,"Pink","RosaRoma","Jomblo", 19);

            obj.CetakData();

        }
    }
}
