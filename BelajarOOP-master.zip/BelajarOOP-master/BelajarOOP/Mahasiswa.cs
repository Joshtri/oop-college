﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BelajarOOP
{
    internal class Mahasiswa
    {
        //Enkapsulasi / Encapsulation.
        private long Nim { get;}
        public string mantan;

        public Mahasiswa()
        {

        }
        
    }
}
