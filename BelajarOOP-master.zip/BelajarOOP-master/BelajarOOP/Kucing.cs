﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BelajarOOP
{
    //internal class Kucing : Singa
    //{
    //    public override void Nakal()
    //    {
    //        Console.WriteLine("Kucing ini tidak nakal, cuman mager");
    //    }

    //    public override void SeleraMakan()
    //    {
    //        Console.WriteLine("Ini kucing lapar, mah laparnya masih sadar diri sedikit deng majikan.");
    //    }
    //}
}
