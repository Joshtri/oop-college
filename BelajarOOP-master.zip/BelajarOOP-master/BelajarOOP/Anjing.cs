﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BelajarOOP
{
    //internal class Anjing : Singa
    //{
        
    //    public override void Nakal()
    //    {
    //        Console.WriteLine("Hewan ini tidak terlalu nakal.");
    //    }

    //    public override void SeleraMakan()
    //    {
    //        Console.WriteLine("Hewan ini lahap tapi sadar diri sonde makan manusia");
    //    }
    //}
}
