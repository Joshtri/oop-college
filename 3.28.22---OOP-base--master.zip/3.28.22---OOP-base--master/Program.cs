﻿using System;

namespace _3._28._22___OOP_base_
{
    class Program
    {
        static void Main(string[] args)
        {
            //membuat objek pertama dari kelas KelasTurunan
            //tanpa parameter 

            KelasTurunan obj = new KelasTurunan(); 

            Console.WriteLine(); 

            //membuat objek pertama dari kelas KelasTUrunan 
            //dengan parameter 
            
            //KelasTurunan obj2 = new KelasTurunan(5);
            KelasTurunan obj2 = new KelasTurunan(4);

            Console.WriteLine();
        }
    }
}
