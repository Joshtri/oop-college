﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OOP_Tesa
{
    internal class Program
    {
        static void Main(string[] args)
        {
            // instansiasi. 
            Programmer Orang1 = new Programmer(30,2,2,2,"Pria","Andre","Software Engineering","KL454123");

            Orang1.DisplayIdentity();
            Orang1.DisplayBehavior();

          
            

                
            
            

           


            

         
           

            

        }

        //public Program()
        //{ 

        //}

        
        //// ini static non-void. need value. 
        //public static int LuasSegitiga()
        //{

        //    return 0; // ada kembalian nilai.  
        //}

        ////ini static void. no need return value.
        //public static void NamaDoi()
        //{
           
        //}
    }
}
